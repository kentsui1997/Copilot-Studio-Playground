# Sources, Feature Notes, and Verification Boundaries

**Documentation checked: 10 September 2026. Workshop: 11 September 2026.**

This is a newly designed lab inspired by the hub-and-specialist pattern in [Copilot Studio Playground](https://github.com/kentsui1997/Copilot-Studio-Playground). It does not import or convert that repository's standard-harness agents, cloud flows, or knowledge content. The synthetic client and coverage content in this kit is newly authored for this exercise.

## Primary documentation used

| Topic | Source | Implication for this lab |
|---|---|---|
| Harness and agent model | [GitHub-harness overview](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/overview) | New agent definitions; instructions/knowledge/tools/connected agents, not a classic Topics rebuild |
| Manual creation | [Create a new agent](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/build-new-agent) | Agents → New agent is the fallback when the builder is unavailable |
| Natural-language builder | [Create with natural language](https://learn.microsoft.com/en-us/microsoft-copilot-studio/create-automation-natural-language) | Builder creates artifacts; documentation still labels this capability preview |
| Settings | [Agent settings](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/settings-overview) | Allow other agents to connect; Microsoft authentication; identity details before first save |
| Knowledge | [Add knowledge sources](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/knowledge-add-existing-copilot) | Upload files under Build → Knowledge; no general-knowledge on/off toggle in this experience |
| Connected agents | [Add a connected agent](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/add-agent-connected) | Same environment, new harness, published specialist, owner or appropriate sharing |
| Trace | [Use activity trace](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/authoring-activity-trace) | Inspect actual calls and source use; do not grade only fluent output |
| Publication | [Publish an agent](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/publication-publish-agent) | Republish changed specialists before Hub retests; honor data policy |
| Workflows | [Create a workflow tool](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/tools-add-workflow) | Optional native workflow, not a legacy cloud-flow conversion |
| Workflow contract | [Add workflow to an agent](https://learn.microsoft.com/en-us/microsoft-copilot-studio/workflows-experience/flow-agent) | Agent trigger, response action, synchronous, published, 100-second action limit |
| Workflow tests | [Workflow designer](https://learn.microsoft.com/en-us/microsoft-copilot-studio/workflows-experience/flow-designer) | Test executes runtime behavior; whole-workflow testing may save/publish |
| Billing | [Usage-based billing](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/billing-credit-overview) | Authoring, Preview, and evaluation may consume credits |
| Evaluation | [Create an evaluation set](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/analytics-agent-evaluation-create) | Use the tenant's current import template, not this kit's JSON schema |

## Important qualifications

1. **Runtime availability is not the same as every feature being GA.** The builder and some adjacent workflow/evaluation pages retain preview labels. Use approved features actually available in the tenant.
2. **Publication is a prerequisite.** The current quickstart says a trial license can test but cannot publish; connected-specialist prerequisites require publication. Validate actual entitlements before class.
3. **Instructions are not deterministic approval or security.** The no-send core has no sending tools. Real business actions require independent authorization and approval controls.
4. **File knowledge is static and generative retrieval is not a complete database query.** The small synthetic snapshot is adequate for this teaching task, not proof of reliable record-level policy administration.
5. **No real Manulife terms are represented.** Product names, distinctions, records, addresses, and communication rules are fictional. Do not use this pack as approved customer-facing material.
6. **No one-click four-agent result is guaranteed.** Verify four actual artifacts, then bind knowledge and connections explicitly. Manual creation preserves the lab if the builder does not cooperate.
7. **Source notes and trace visibility differ.** Retain valid citations; never fabricate them. If nested evidence is unavailable, inspect specialists separately and document that limitation.
8. **Same-environment sharing is not cross-environment migration.** This lab makes no claim that standard agents can connect directly to new-harness agents or be converted by importing an old solution.
9. **Memory off does not mean no records.** Platform conversation history, transcripts, logs, and retention remain subject to environment configuration.
10. **Local checks are not tenant rehearsal.** Build validation covers files, links, Office packages, PDF generation, and portal interaction. It does not create or execute Copilot Studio agents.

## What has and has not been tested

The generated validation report records local build checks. The facilitator must complete the separate tenant preflight, run the demonstration set, and test with participant permissions. Illustrative answers in the runbook are explicitly examples, not captured execution output.

No claim is made about production accuracy, suitability, regulatory approval, data residency, comparative model performance, or guaranteed cost/time savings. Those require a separately governed implementation and evaluation.
