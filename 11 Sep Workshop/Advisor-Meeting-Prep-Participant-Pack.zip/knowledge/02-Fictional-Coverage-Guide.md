# Fictional Coverage Guide

**FICTIONAL WORKSHOP CONTENT — NOT MANULIFE PRODUCTS, PRICING, OR UNDERWRITING RULES**

Version 1.0 | Effective for this training exercise: **11 September 2026**

## Scope and limitations

The following simplified **Contoso Assurance** product concepts exist only to teach grounded agent responses. They are not available for purchase and must not be described as actual Manulife products. The guide supports comparisons and advisor discussion questions, not financial advice, suitability approval, underwriting, or claim adjudication.

There are **no premiums, quotes, age-entry limits, medical criteria, waiting periods, payout percentages, guaranteed returns, or guaranteed acceptance rules** in this guide. Do not supply any of those from general knowledge. A client's stated budget does not establish whether any option is affordable.

For a real customer, only authorized staff and approved current product documents can establish product terms and eligibility. Human advisor review is required before using any lab-style output in a real interaction.

## Product FT10 — Contoso Family Term 10

- **Category:** Illustrative term-life protection.
- **Conceptual benefit:** A death benefit during a stated term, subject to policy terms and a valid claim.
- **Illustrative term:** 10 years.
- **Purpose for discussion:** Family financial protection following the insured person's death.
- **Critical-illness lump-sum benefit:** Not part of this fictional product concept.
- **Hospital-expense reimbursement:** Not part of this fictional product concept.
- **Cash value or investment return:** No such benefit is specified; do not invent one.
- **Premium and eligibility:** Not supplied.
- **Advisor discussion question:** What financial commitments and dependants should a needs analysis consider?

## Product CM1 — Contoso Care Medical

- **Category:** Illustrative hospital-expense reimbursement.
- **Conceptual benefit:** Reimbursement of eligible hospital expenses, subject to policy terms and a valid claim.
- **Purpose for discussion:** Understanding how eligible medical expenses differ from an unrestricted lump-sum concept.
- **Critical-illness lump-sum benefit:** Not part of this fictional product concept.
- **Death benefit:** Not part of this fictional product concept.
- **Spouse or family rider:** Not supplied. Do not claim spouse cover is included or can automatically be added.
- **Annual benefit limits, deductibles, networks, and waiting periods:** Not supplied.
- **Premium and eligibility:** Not supplied.
- **Advisor discussion question:** Which existing benefits, reimbursement conditions, and family requirements need clarification?

## Product CIB — Contoso Critical Care Basic

- **Category:** Illustrative critical-illness lump-sum protection.
- **Conceptual benefit:** A lump-sum benefit for a covered critical illness, subject to policy definitions, underwriting, and a valid claim.
- **Purpose for discussion:** Financial flexibility following a covered critical-illness event; distinct from death-only life cover and hospital reimbursement.
- **Early-stage benefit:** Not included in this fictional Basic concept.
- **Hospital-expense reimbursement:** Not part of this fictional product concept.
- **Covered-condition list, benefit amount, medical definitions, and payout percentages:** Not supplied.
- **Premium and eligibility:** Not supplied.
- **Advisor discussion question:** What financial commitments and recovery-related needs should the advisor explore?

## Product CIP — Contoso Critical Care Plus

- **Category:** Illustrative critical-illness lump-sum protection.
- **Conceptual benefit:** The covered critical-illness lump-sum concept described for Basic, plus an illustrative early-stage benefit, subject to policy terms, underwriting, and a valid claim.
- **Purpose for discussion:** Exploring whether an additional early-stage benefit is relevant to the client's needs.
- **Early-stage benefit:** Included as a concept only. No amount, percentage, diagnosis definition, or payment sequence is supplied.
- **Hospital-expense reimbursement:** Not part of this fictional product concept.
- **Premium and eligibility:** Not supplied. Do not infer that Plus is affordable, better value, or the most suitable option.
- **Advisor discussion question:** Which early-stage definitions, limits, exclusions, and costs would need to be checked in actual approved materials?

## Comparison reference

| Fictional concept | Benefit basis | Early-stage critical-illness benefit | Hospital-expense reimbursement |
|---|---|---|---|
| Contoso Family Term 10 | Death benefit during a 10-year term | Not included | Not included |
| Contoso Care Medical | Eligible hospital-expense reimbursement | Not included | Included conceptually; limits not supplied |
| Contoso Critical Care Basic | Covered critical-illness lump sum | Not included | Not included |
| Contoso Critical Care Plus | Covered critical-illness lump sum | Included conceptually; details not supplied | Not included |

## Applying the guide to a discussion pack

1. Identify the client's stated discussion goal. Do not infer diagnoses or risk scores.
2. Separate existing cover stated in the snapshot from potential discussion options in this guide.
3. Explain relevant differences. For a critical-illness discussion, Basic and Plus provide a useful illustrative comparison.
4. Identify missing information. General education does not require every profile field, but personalized next steps require a proper needs analysis.
5. Explicitly say that prices and eligibility are unavailable in the lab.
6. Present **options for advisor discussion**, not a purchase recommendation or a suitability decision.

Suggested closing: **"These are fictional workshop options for advisor discussion. Premiums, eligibility, and final suitability have not been determined."**

## Source reference

Refer to **Fictional Coverage Guide, Product FT10 / CM1 / CIB / CIP**, as appropriate. Retain valid platform citations where available; do not invent links or citations. The guide contains no Manulife product terms.