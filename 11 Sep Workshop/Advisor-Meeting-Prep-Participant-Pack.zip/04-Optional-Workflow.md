# Optional Lab — A Deterministic Meeting Window

**15 minutes | Begin only after the four-agent core works.**

Add a native GitHub-harness workflow to **Follow-up Drafting**. It computes a proposed meeting end time using built-in date/time operations. **No Outlook connection, availability check, reservation, email, or business-record write is involved.**

## Outcome

User asks: **Use the Meeting Window workflow to calculate a proposed 45-minute meeting starting 2026-09-15T14:00:00 Hong Kong local time. Do not book anything.**

Expected: an actual workflow call returning **2026-09-15T14:45:00**, with **PROPOSED — NOT BOOKED** and **Hong Kong (UTC+08:00)**. An LLM correctly doing the arithmetic without calling the workflow does not meet this exercise's objective.

## 1. Generate the workflow (5 minutes)

1. Open the workshop portal, choose your team key, and copy **Optional workflow builder**.
2. Paste it into the Copilot Studio **builder chat**, not the agent's Preview.
3. Request one native workflow named **FSI-P01 Meeting Window**, substituting your prefix.
4. Open the artifact with **Edit**. Do not assume a generated graph is correct until you review it.

Alternative: **Follow-up Drafting → Build → Tools → Add → Workflow**, or **Workflows → New workflow**, in the GitHub-harness experience. Build the small graph below in the designer. Do not create a standard agent flow through Other ways to build.

## 2. Verify the contract and graph (4 minutes)

### Trigger: When an agent calls the flow

| Input | Type | Rule |
|---|---|---|
| StartDateTime | Text | Required; yyyy-MM-ddTHH:mm:ss in Hong Kong local wall-clock time |
| DurationMinutes | Number | Required; exactly 30, 45, or 60 |

This exercise does not perform timezone conversion. Do not append Z to Hong Kong local time; Z means UTC. If the user supplies another zone, clarify rather than silently changing it.

### Deterministic steps

1. Add a **Condition** that permits DurationMinutes equal to 30 **OR** 45 **OR** 60.
2. In the valid branch, use a built-in date/time operation to add that number of minutes to StartDateTime.
3. Format the result as yyyy-MM-ddTHH:mm:ss.
4. In the invalid-duration branch, do not calculate an end time.
5. Return the same four Text outputs from either validation branch.

Where the designer offers workflow expressions, the operation is **addMinutes(start, minutes, format)**. Insert the actual trigger tokens from the current designer; do not blindly paste old triggerBody text/text_1 references from a different flow. Use the generated expression only after confirming its inputs and output in a test.

| Output | Valid duration | Invalid duration |
|---|---|---|
| Status | Calculated | InvalidDuration |
| EndDateTime | Calculated local ISO time | Empty text |
| TimeZone | Hong Kong (UTC+08:00) | Hong Kong (UTC+08:00) |
| Message | Proposed time only; no calendar checked and no meeting booked. | Use 30, 45, or 60 minutes. |

### Response requirements

- End the applicable branch with **Respond to the agent**.
- Set **Asynchronous response → Off** under the action's Networking settings if exposed.
- A workflow added as a tool must be published and respond within the documented **100-second action limit**. This tiny calculation should not need a long-running operation.
- A malformed date must not produce Status Calculated. A surfaced workflow error is acceptable for this optional lab if the designer does not provide a simple error branch.
- Confirm there are no connector, LLM, schedule, or business-write nodes.

## 3. Test, publish, and attach (4 minutes)

The designer's whole-workflow **Test** may save and publish changes as part of the test. Only test after reviewing the graph. A node test also executes that node; “mock inputs” is not a guarantee of a simulated connector call.

Run these direct workflow tests:

| Test | StartDateTime | DurationMinutes | Expected |
|---|---|---|---|
| T11 | 2026-09-15T14:00:00 | 45 | Calculated; 2026-09-15T14:45:00 |
| T12 | 2026-09-15T23:45:00 | 30 | Calculated; 2026-09-16T00:15:00 |
| T13 | 2026-09-15T14:00:00 | 90 | InvalidDuration; empty EndDateTime |
| Extra | not-a-date | 30 | Error or validation failure; never Calculated |

Then:

1. Resolve designer errors; **Save → Publish**.
2. Open **Follow-up Drafting → Build → Tools → Workflows** and add your published Meeting Window workflow.
3. Give the tool a description: **Calculate a proposed meeting end time from a Hong Kong local start time and 30/45/60-minute duration. No calendar access or booking.**
4. Append **Optional workflow agent delta** from the portal to Follow-up Drafting's existing instructions. Do not replace the core instructions.
5. Save and **republish Follow-up Drafting** before testing through the Hub.
6. Add this short routing rule to the Hub instructions: **For an explicit request to calculate a proposed meeting window, delegate to the Follow-up Drafting specialist. Do not calculate it yourself or say a meeting was booked.** Save; republish the Hub only if using its published channel.

## 4. Verify end-to-end (2 minutes)

1. First test the opening prompt in Follow-up Drafting Preview.
2. Repeat through the Hub in a fresh conversation.
3. Inspect the workflow call and actual returned end time. If nested details are not shown in the Hub trace, inspect the workflow run separately.
4. Confirm **PROPOSED — NOT BOOKED** and no claim that a calendar was checked.
5. Re-run the core no-send test. The new calculation tool must not weaken that boundary.

## If the workflow is not listed

Verify GitHub-harness workflow, correct environment, successful publication, When an agent calls the flow, Respond to the agent, synchronous response, and maker access. Do not try to import the old repository's cloud-flow package as a shortcut for this new workflow.

If the new workflow feature is unavailable or blocked, stop this extension and complete the core tests. Do not quietly replace the deterministic tool with an LLM calculation and mark it passed.

## Discussion

The agent chooses when to call the tool and supplies arguments; the workflow deterministically validates duration and calculates time. The result is not an appointment, and the conversation is not an approval system. A real scheduling extension needs authorized calendar access, timezone handling, approval, failure handling, and duplicate prevention.

References: [Create a workflow tool](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/tools-add-workflow), [tool prerequisites](https://learn.microsoft.com/en-us/microsoft-copilot-studio/workflows-experience/flow-agent), [designer and testing](https://learn.microsoft.com/en-us/microsoft-copilot-studio/workflows-experience/flow-designer). Checked 10 September 2026; adjacent workflow tooling may still carry preview labels.
