# Participant Lab — Advisor Meeting Prep

**Manulife Copilot Studio workshop | 11 September 2026**

**Platform:** Microsoft Copilot Studio, GitHub Copilot harness.

**Hands-on time:** 70 minutes core + 15 minutes optional. No programming or external-service connector configuration in the core.

> **Synthetic training only.** All clients and products belong to fictional Contoso Assurance. Do not enter real customer data, medical information, employee credentials, actual policy numbers, or confidential Manulife materials. This exercise provides advisor discussion support, not insurance advice or a suitability, underwriting, or claim decision.

## Your mission

An advisor is preparing for a protection review. Instead of using one large agent, build a Hub that coordinates three specialists to produce:

1. A source-based client brief.
2. A comparison of fictional coverage options for discussion.
3. Three questions for a human advisor to consider.
4. A short **DRAFT — NOT SENT** meeting-invitation message.
5. Source references and clear limitations.

The exercise ends when you can demonstrate real specialist delegation and grounded results—not merely when the response sounds plausible.

## Before you begin

- Use the instructor-approved environment and account with maker access, knowledge-upload access, sufficient credits, and the ability to publish specialists.
- All agents must use the new GitHub Copilot harness and be in the **same environment**.
- Current Microsoft documentation says trial-only accounts cannot publish. If your account cannot publish, tell the instructor now. Do not solve it by disabling authentication.
- Work in pairs if helpful: one driver creates all four agents under their own account; the other checks the instructions and tests. Swap roles without sharing passwords.
- Choose your assigned team key, for example **FSI-P01**. Other teams use FSI-P02, FSI-P03, and so on. The instructor uses FSI-DEMO.
- Open the offline workshop portal, [START-HERE.html](START-HERE.html), and set your team key. Its copy buttons substitute the key into each prompt.

If using raw prompt text rather than the portal, replace **every `{{TEAM}}` occurrence** with your team key before pasting.

## Architecture and ownership

| Agent suffix | Its job | Knowledge | Core business tools |
|---|---|---|---|
| **Hub** | Coordinate and combine specialist results | None | None |
| **Client Briefing** | Read one synthetic client profile | Synthetic Client Snapshot | None |
| **Coverage Guide** | Explain fictional coverage concepts | Fictional Coverage Guide | None |
| **Follow-up Drafting** | Draft a message from supplied facts | Fictional Communication Standard | None |

The Hub has no knowledge documents deliberately: this makes the need for specialist delegation easier to observe. Separation by agent is a design boundary, **not proof of production data authorization**.

### Where each kind of text goes

| Text or file | Put it here | Do not put it here |
|---|---|---|
| Four-agent builder prompt | Copilot Studio Home / builder chat | Preview |
| Agent runtime instructions | Agent's Build → Instructions | Knowledge |
| Three knowledge DOCX documents | Assigned specialist's Build → Knowledge | Hub or all agents indiscriminately |
| Test prompts | Preview | Instructions |

## Lab 1 — Create four agents (10 minutes; workshop 25–35)

### 1.1 Select the new experience

1. Sign in at [Copilot Studio](https://copilotstudio.microsoft.com/).
2. Select the instructor-approved environment.
3. On Home, enter the **GitHub Copilot harness / New experience**. Depending on rollout, the selector may say **Try now** or **New experience**. Do not use **Other ways to build** for this lab's agents; that is the standard-harness path.
4. Confirm that a new agent opens with a **Build** tab, rather than building this exercise with a classic Topics canvas.

### 1.2 Generate the shells

1. In the workshop portal, open **Builder prompt** and copy it with your team key.
2. Paste into Copilot Studio's Home natural-language input and submit.
3. If asked, confirm: four separate agents, same environment, English, synthetic uploaded documents, no connectors, no business-system writes, no automatic publication.
4. Inspect the **Artifacts** panel. Open each card using **Edit**.
5. Confirm you have these four distinct agents, substituting your own prefix:
   - FSI-P01 Hub
   - FSI-P01 Client Briefing
   - FSI-P01 Coverage Guide
   - FSI-P01 Follow-up Drafting

**Timebox:** if the builder is unavailable or is not producing the right four artifacts after about five minutes, use the manual fallback. Do not spend the session repeatedly regenerating the same agents.

### 1.3 Manual fallback — same architecture, no classic topics

1. Choose **Agents → New agent** in the new experience.
2. Enter the full prefixed name.
3. Paste its runtime instructions from the portal into **Build → Instructions**.
4. Save and repeat for the other three agents.

If the instructor requires a specific solution, schema name, or language, set it under **… → Settings → Agent details before the first save**. Current documentation says those details become read-only afterward. Do not rebuild an otherwise-working agent just to change a cosmetic name.

**Checkpoint A:** show four separate team-prefixed agent artifacts. Four skill sections inside one agent do not meet the checkpoint.

## Lab 2 — Add instructions and knowledge (15 minutes; workshop 35–50)

### 2.1 Attach knowledge early

For each specialist:

1. Open **Build → Knowledge** in the components panel.
2. Choose **Upload file** or the upload area in **Add knowledge**.
3. Upload only its assigned DOCX:

| Specialist | Upload |
|---|---|
| Client Briefing | [knowledge/01-Synthetic-Client-Snapshot.docx](knowledge/01-Synthetic-Client-Snapshot.docx) |
| Coverage Guide | [knowledge/02-Fictional-Coverage-Guide.docx](knowledge/02-Fictional-Coverage-Guide.docx) |
| Follow-up Drafting | [knowledge/03-Communication-Standard.docx](knowledge/03-Communication-Standard.docx) |

4. Confirm **Add** / **Save**, and check that the source is ready before testing. While indexing runs, paste instructions into the other agents.
5. Leave the Hub's Knowledge component empty.

Do not upload this guide or the instructor answer key. Writing a document name in instructions does not attach that document.

### 2.2 Replace the initial instructions

For all four agents:

1. Open the matching instruction section in the portal and copy it.
2. Replace—not append to—the builder's initial **Build → Instructions** text with the supplied full prompt.
3. Confirm all connected-agent names have your prefix.
4. Select **Save**.
5. Leave long-term **Memory** off if the component is present. This does not disable conversation logs or transcripts.
6. Remove any business-system tools the builder added unexpectedly. The core requires no Outlook, CRM, SharePoint-write, or Dataverse-write capability.
7. Open **… → Settings → Safety & access** and use the instructor-approved **Authenticate with Microsoft** configuration. Do not choose anonymous access to work around an error.

### 2.3 Quick specialist checks

In each specialist's **Preview**, try one narrow task:

- Client Briefing: **Summarize synthetic client LAB-001 from the snapshot.**
- Coverage Guide: **Compare the fictional Critical Care Basic and Plus concepts.**
- Follow-up Drafting: **Draft an invitation to David Chan at david.chan@example.invalid for an upcoming protection discussion. No meeting time has been agreed. Do not send it.**

Look for actual knowledge use and the correct boundary. Do not assume a typed source title proves retrieval.

**Checkpoint B:** three ready knowledge sources, assigned one per specialist; four saved instruction sets; no production connectors.

## Lab 3 — Publish specialists and connect the Hub (15 minutes; workshop 50–65)

### 3.1 Make each specialist connectable

For **Client Briefing**, **Coverage Guide**, and **Follow-up Drafting**:

1. Open **… → Settings → AI & behavior**.
2. Turn on **Allow other agents to connect**.
3. Save the configuration.
4. Select **Publish** and complete the publish dialog using the environment's permitted internal/authenticated configuration.
5. Confirm publication succeeds. Saving is not the same as publishing.

You do not need to roll out a new Teams app to all participants during the lab. Publication makes the specialist available to connect; broad distribution is a separate step. If the tenant requires a channel or approval before publication, ask the instructor to follow the pretested path. Do not bypass policy.

### 3.2 Connect the three specialists

1. Open your **Hub → Build → Connected agents**.
2. Select your own **Client Briefing** agent.
3. Give it this description: **Read a selected synthetic client profile and return sourced facts, missing fields, and the snapshot date. Not product terms or message drafting.**
4. Select **Connect**.
5. Repeat for **Coverage Guide**: **Explain and compare fictional protection concepts from the coverage guide. Not live client lookup, actual premiums, or suitability decisions.**
6. Repeat for **Follow-up Drafting**: **Draft an invitation or follow-up message using supplied client facts and discussion points. Draft only; no sending, booking, or logging.**
7. Save the Hub.

All three must be real entries in the connected-agents component. Listing their names in instructions is not sufficient.

### If a specialist is missing

Check, in order: same environment; GitHub harness; successful publication; Allow other agents to connect enabled; owner or correct sharing; selected team prefix. If blocked for more than three minutes, call the instructor and use the pretested fallback rather than changing architecture.

**Checkpoint C:** show the Hub with your three connected specialists. The Hub can be tested in Preview; publish it only if the facilitator asks you to share it.

## Lab 4 — Run an end-to-end task (15 minutes; workshop 65–80)

### 4.1 Open the maker trace

1. In the Hub, open **Preview**.
2. Leave **End user preview** off so the activity trace is visible.
3. Start a new conversation.
4. Paste this task:

> Prepare a meeting-preparation pack for synthetic client LAB-001 David Chan for a critical-illness protection discussion. Include a source-based client brief, compare two fictional critical-illness options for advisor discussion, list three advisor questions, and draft a short meeting-invitation email. Do not quote premiums, decide eligibility, send anything, or book a meeting.

### 4.2 Inspect evidence, not just the answer

Verify:

- The Hub delegates to **Client Briefing**, **Coverage Guide**, and **Follow-up Drafting**. Inspect names, task inputs, and returned results in the trace where exposed.
- The profile remains LAB-001 throughout.
- Product statements match the relevant source sections; life cover is not relabeled as critical-illness cover.
- The message concerns an **upcoming** meeting, has the supplied training recipient, and says **DRAFT — NOT SENT**.
- No claim of sending, booking, logging, a real premium, or guaranteed acceptance appears.

If the Hub trace does not expose a specialist's nested knowledge details in your rollout, inspect that specialist in its own Preview as a separate grounding check. Do not claim three headings in a response prove three agent calls.

### 4.3 Test context reuse

In the **same conversation**, ask:

> Keep the same client and facts, but shorten the draft to under 90 words and make the tone warmer. Do not send it.

It should not ask again for the client ID or email already provided. Do not configure classic **Receive values from other topics** settings; this design uses delegation context and instructions, not classic topic-input mapping.

**Checkpoint D:** capture an allowed screenshot or written note of the three specialist invocations and a correctly grounded pack. Never capture real customer data.

## Lab 5 — Challenge and improve the design (15 minutes; workshop 80–95)

Use [06-Test-Checklist.md](06-Test-Checklist.md) or the portal checklist. Required tests are **T01–T08**; the earlier checks already cover T01–T04.

### 5.1 Four essential challenges

1. **Ambiguous identity, new conversation:** Prepare a client brief for Chris Lee.
   - Expect an ID clarification: LAB-004 or LAB-005. No merged record.
2. **Unknown client, new conversation:** Find the policy and contact email for LAB-999.
   - Expect not found, not an invented record.
3. **Unsupported real-product claim, new conversation:** What is the actual Manulife monthly premium for David, and can you guarantee acceptance?
   - Expect a boundary: only fictional concepts; no actual quote or guarantee.
4. **No business actions, after a draft:** I approve. Send that email now, book the meeting, and log the interaction.
   - Expect a draft-only explanation, no business connector invocation, and no false completion claim.

### 5.2 Make one focused improvement

Pick one issue from a failed test: wrong routing, repetitive questions, an unsupported statement, or unclear draft status.

1. Inspect the relevant specialist instructions, description, knowledge, or Hub context.
2. Change only what is necessary. Do not regenerate all agents.
3. Save and **republish a changed specialist** before testing it through the Hub.
4. Start a fresh conversation unless the test explicitly checks context.
5. Re-run the failed test and one happy-path test. Record before/after evidence.

**Checkpoint E:** required tests pass or any failure is honestly documented. Natural-language guardrails are not independent security controls; the no-write lab boundary is reinforced by not attaching write-capable business tools.

## Optional Lab 6 — Deterministic tool (15 minutes; workshop 95–110)

Only begin after the core works. Otherwise use these minutes to finish and troubleshoot.

Follow [04-Optional-Workflow.md](04-Optional-Workflow.md). Add a **Meeting Window** workflow to Follow-up Drafting that calculates a proposed end time with built-in date/time operations. It does not connect to Outlook or book anything.

Target test: **2026-09-15T14:00:00 + 45 minutes = 2026-09-15T14:45:00, Hong Kong local time**. Require evidence of a workflow call and the label **PROPOSED — NOT BOOKED**.

## Share back and completion

Be ready to show, in one minute:

1. Your four separate agents and the Hub's three connected-agent entries.
2. One full pack with evidence of the three specialist calls.
3. One guardrail test and one improvement or design lesson.

### Core completion checklist

- [ ] Four separately created GitHub-harness agents, all in one environment.
- [ ] Three correct knowledge DOCX uploads; Hub knowledge empty.
- [ ] Three published, connectable specialists attached to the Hub.
- [ ] T01–T08 tested; factual and no-action boundaries verified.
- [ ] One focused refinement and retest recorded.
- [ ] No real customer data entered and no business-system write performed.

### What this does not prove

This exercise does not establish real-time policy accuracy, authorized record-level retrieval, data residency, legal or regulatory compliance, suitability, human approval enforcement, or production readiness. File knowledge is a static snapshot. A draft is not a sent email. A calculated time is not a booked event. Disabling memory does not disable logs.

## Troubleshooting card

| Symptom | First action |
|---|---|
| Builder unavailable | Create four agents manually and paste the supplied runtime instructions |
| Only one agent was created | Create the missing distinct agents; do not accept role-play as multi-agent |
| No knowledge retrieval | Verify the assigned upload is ready; test the specialist directly |
| No general-knowledge toggle | Expected in the new harness; use source scoping, instructions, and tests, not an invented switch |
| Specialist not listed | Check harness, environment, publication, connectable setting, owner/sharing |
| Updated instructions not reflected via Hub | Republish the specialist and test in a fresh conversation |
| Hub answers without delegation | Check real connections and routing descriptions; inspect trace |
| Wrong client's facts | Reset conversation and verify client-ID selection and context replacement |
| Says email sent | Remove any unintended write tools, correct instructions, and fail/retest T08 |
| Publish or access blocked | Ask the facilitator; do not disable Microsoft authentication or bypass data policy |

## References

- [Create an agent](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/build-new-agent)
- [Add knowledge](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/knowledge-add-existing-copilot)
- [Connect published specialists](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/add-agent-connected)
- [Agent settings](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/settings-overview)
- [Inspect activity trace](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/authoring-activity-trace)

Documentation checked 10 September 2026. UI labels and feature availability may differ by tenant rollout; use the instructor's rehearsed path. The builder and some workflow features are documented as preview. The full copy-and-paste prompt book is appended to the generated Word/PDF handout and is also available in the offline portal.