# T08-Advanced — Outlook Email Supplement

**OPT-IN: CAN SEND REAL EMAIL.** Requires a completed core workshop and separately approved Outlook identity/recipient/approval configuration.

Extract this entire ZIP and open [START-HERE.html](START-HERE.html). It contains the click-by-click guide, full new-Hub prompts, ten manual tests, PDF/Word handouts, and a manual-Outlook-send fallback. Copy buttons never send email. Configure the real tool only in the approved Copilot Studio environment.

One new Email Hub reuses the existing three specialists. Do not modify the original no-write Hub or core T08 tests. Keep booking/logging unavailable. Verify actual sender identity with a non-maker user and a controlled training recipient.

The exact per-run confirmation toggle is not verified in the new-harness docs; do not present instruction-only chat approval as deterministic enforcement. No tenant connections, agents, or emails were created by this pack-generation process.
